// SkillBridge AI backend starter.
// Install Express and add API routes here when converting the prototype to a full-stack app.

const express = require("express");
const app = express();

app.use(express.json());

app.get("/api/health", (req, res) => {
  res.json({ status: "ok", project: "SkillBridge AI" });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`SkillBridge API running on port ${PORT}`));

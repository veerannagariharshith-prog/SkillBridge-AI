# SkillBridge AI

## Problem Statement
**Mapping Skill Gaps to Industry Needs**

SkillBridge AI is a prototype platform that helps students understand how their current skills compare with industry/job requirements. It identifies matched skills, missing skills, an overall match percentage, and recommended areas for improvement.

## Features
- Student skill profile
- Industry/job requirement comparison
- Skill-gap analysis
- Job matching
- Career-readiness dashboard
- Learning/skill recommendations

## Technology
- Frontend: HTML, CSS, JavaScript prototype
- Backend: Node.js / Express-ready structure
- AI/ML: Python-ready structure
- Database: PostgreSQL-ready schema

## Run the prototype
Open `frontend/index.html` in a browser.

The prototype is intentionally simple so it can be demonstrated and extended into a full-stack application.

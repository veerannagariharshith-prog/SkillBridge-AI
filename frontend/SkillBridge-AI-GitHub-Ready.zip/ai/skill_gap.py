def calculate_skill_gap(user_skills, required_skills):
    user = {skill.strip().lower() for skill in user_skills}
    required = [skill.strip() for skill in required_skills]

    matched = [skill for skill in required if skill.lower() in user]
    missing = [skill for skill in required if skill.lower() not in user]

    percentage = round((len(matched) / len(required)) * 100) if required else 0

    return {
        "matched": matched,
        "missing": missing,
        "match_percentage": percentage
    }


if __name__ == "__main__":
    user = ["Python", "HTML", "CSS", "JavaScript"]
    required = ["HTML", "CSS", "JavaScript", "React", "Git"]
    print(calculate_skill_gap(user, required))

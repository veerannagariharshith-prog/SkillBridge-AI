# System Architecture

Student
↓
SkillBridge AI Web Application
↓
User Profile & Skill Data
↓
Skill Analysis Engine
↓
Skill Gap Detection
↓
Industry & Job Requirements
↓
Job Matching
↓
Recommendations & Dashboard

## Main Components

### User Interface
Collects student education, skills, projects and career interests.

### Skill Analysis
Organizes and compares the user's current skills.

### Skill Gap Detection
Finds skills required by a target role but not present in the user's profile.

### Industry Matching
Ranks job roles according to the user's current skills.

### Recommendation System
Suggests missing skills to improve job readiness.

### Dashboard
Displays match percentage, skill gaps and recommendations.

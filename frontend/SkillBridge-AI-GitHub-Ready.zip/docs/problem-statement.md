# Problem Statement

## Mapping Skill Gaps to Industry Needs

Students often have difficulty understanding whether their current skills match the requirements of industry and available job roles.

SkillBridge AI helps identify existing skills, compare them with industry requirements, identify missing skills, and provide suitable career and skill-development recommendations.

## Objective

The platform aims to help users:
- Identify existing skills
- Understand industry-required skills
- Detect skill gaps
- Find suitable job roles
- Identify skills that need improvement
- Improve career readiness
